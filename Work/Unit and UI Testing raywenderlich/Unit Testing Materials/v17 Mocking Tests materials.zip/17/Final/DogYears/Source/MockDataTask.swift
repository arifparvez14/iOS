//
//  MockDataTask.swift
//  DogYears
//
//  Created by Brian on 12/12/17.
//  Copyright © 2017 Razeware. All rights reserved.
//

import Foundation

class MockDataTask: URLSessionDataTaskProtocol {
  func resume() {
  
  }
}
