//
//  URLSessionDataTaskProtocol.swift
//  DogYears
//
//  Created by Brian on 12/12/17.
//  Copyright © 2017 Razeware. All rights reserved.
//

import Foundation

protocol URLSessionDataTaskProtocol {
  func resume()
}
